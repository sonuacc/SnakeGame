public class SnakeGame {

	public static void main(String[] args) {
		
		 new GameFrame(); // creating object of GameFrame()
	}
}